package render

import (
	uv "github.com/charmbracelet/ultraviolet"
	"github.com/charmbracelet/x/ansi"
	"github.com/kazuph/ikesu/internal/layout"
	"image/color"
	"math"
	"strings"
)

// --- menu ---

// MenuSize computes the box size for a menu.
func MenuSize(m *Menu) (w, h int) {
	w = 0
	for _, it := range m.Items {
		l := len([]rune(it.Label))
		if it.Separator {
			l = 2
		}
		if l > w {
			w = l
		}
	}
	w += 4 // padding + border
	w = max(w, m.MinWidth)
	return w, len(m.Items) + 2
}

// MenuRect positions a menu inside (cols, rows).
func MenuRect(m *Menu, cols, rows int) layout.Rect {
	if m.Worktree {
		return WorktreeMenuRect(m, cols, rows)
	}
	w, h := MenuSize(m)
	w, h = min(w, max(0, cols)), min(h, max(0, rows))
	x, y := m.X, m.Y
	if x+w > cols {
		x = cols - w
	}
	if y+h > rows {
		y = rows - h
	}
	if x < 0 {
		x = 0
	}
	if y < 0 {
		y = 0
	}
	return layout.Rect{X: x, Y: y, W: w, H: h}
}

// MenuScroll keeps the selected item visible and preserves the viewport on mouse movement.
func MenuScroll(m *Menu, rows int) int {
	height := max(0, min(len(m.Items), rows-2))
	offset := min(max(0, m.Scroll), max(0, len(m.Items)-height))
	if m.Sel >= 0 && m.Sel < len(m.Items) {
		if m.Sel < offset {
			offset = m.Sel
		}
		if m.Sel >= offset+height {
			offset = m.Sel - height + 1
		}
	}
	return min(max(0, offset), max(0, len(m.Items)-height))
}

func drawMenu(f *Frame, m *Menu, out *Output) {
	if m.Worktree {
		drawWorktreeMenu(f, m, out)
		return
	}
	r := MenuRect(m, f.W, f.H)
	border := uv.Style{Fg: f.Palette.Accent, Bg: f.Palette.PopupBG}
	ix, iy, iw, ih := f.Box(r.X, r.Y, r.W, r.H, border)
	f.Fill(ix, iy, iw, ih, " ", uv.Style{Fg: f.Palette.Text, Bg: f.Palette.PopupBG})
	if m.Global {
		f.Fill(ix, iy, iw, ih, " ", uv.Style{Bg: f.Palette.PopupBG})
	}
	out.MenuRect = r
	out.MenuItemRows = make([]layout.Rect, len(m.Items))
	m.Scroll = MenuScroll(m, f.H)
	for i := m.Scroll; i < len(m.Items); i++ {
		it := m.Items[i]
		y := iy + i - m.Scroll
		if y >= iy+ih {
			break
		}
		row := layout.Rect{X: ix, Y: y, W: iw, H: 1}
		out.MenuItemRows[i] = row
		if it.Separator {
			if m.Global {
				f.Fill(ix, y, iw, 1, "─", uv.Style{Fg: f.Palette.PanelBG, Bg: f.Palette.PopupBG})
			} else {
				f.Text(ix+1, y, " --", uv.Style{Fg: f.Palette.Dim, Bg: f.Palette.PopupBG}, ix+iw)
			}
			continue
		}
		sty := uv.Style{Fg: f.Palette.Text, Bg: f.Palette.PopupBG}
		if i == m.Hover || i == m.Sel {
			sty = uv.Style{Fg: f.Palette.SurfDim, Bg: f.Palette.Accent, Attrs: uv.AttrBold}
			if !m.Global {
				f.Fill(ix, y, iw, 1, " ", sty)
			}
		}
		if it.Disabled {
			sty = uv.Style{Fg: f.Palette.Dim, Bg: f.Palette.PopupBG}
		}
		if m.Global {
			f.Text(ix, y, " "+it.Label+" ", sty, ix+iw)
		} else {
			f.Text(ix+1, y, it.Label, sty, ix+iw-1)
		}
	}
}

// --- toast ---

func drawMobileToast(f *Frame, t *Toast, out *Output) {
	y := f.H - 1
	out.ToastRect = layout.Rect{Y: y, W: f.W, H: 1}
	bg := f.Palette.Surface
	f.Fill(0, y, f.W, 1, " ", uv.Style{Bg: bg})
	color := f.Palette.Blue
	if t.Kind == "needs_attention" {
		color = f.Palette.Red
	}
	f.Set(1, y, "●", uv.Style{Fg: color, Bg: bg})
	title := t.Title
	if t.Kind == "info" {
		title = "update ready"
	}
	x := f.Text(3, y, title, uv.Style{Fg: f.Palette.Text, Bg: bg, Attrs: uv.AttrBold})
	if t.Body != "" {
		f.Text(x, y, " · "+t.Body, uv.Style{Fg: f.Palette.Dim, Bg: bg})
	}
}

// drawToast renders the status title and an optional body inside the notification border.
func drawToast(f *Frame, t *Toast, out *Output) {
	r := ToastRect(t, layout.Rect{W: f.W, H: f.H}, out.ConfigWarningRect)
	out.ToastRect = r
	dot := uv.Style{Fg: f.Palette.Blue, Bg: f.Palette.PopupBG}
	if t.Kind == "needs_attention" {
		dot.Fg = f.Palette.Red
	}
	ix, iy, iw, ih := f.Box(r.X, r.Y, r.W, r.H, uv.Style{Fg: f.Palette.Dim, Bg: f.Palette.PopupBG})
	f.Fill(ix, iy, iw, ih, " ", uv.Style{Bg: f.Palette.PopupBG})
	f.Set(ix, iy, "●", dot)
	f.Text(ix+2, iy, t.Title, uv.Style{Fg: f.Palette.Text, Bg: f.Palette.PopupBG, Attrs: uv.AttrBold}, ix+iw)
	if t.Body != "" && ih > 1 {
		f.Text(ix, iy+1, "  "+t.Body, uv.Style{Fg: f.Palette.Dim, Bg: f.Palette.PopupBG}, ix+iw)
	}
}

// ToastRect uses terminal cell widths, including wide and combining characters.
func ToastRect(t *Toast, view, warning layout.Rect) layout.Rect {
	w := min(max(ansi.StringWidth(t.Title), ansi.StringWidth(t.Body))+6, max(0, view.W))
	y := view.Y
	if warning.H > 0 {
		y = max(y, warning.Y+warning.H)
	}
	h := 3
	if t.Body != "" {
		h = 4
	}
	bottom := view.Y + view.H
	if warning.H > 0 && strings.HasPrefix(t.Position, "bottom-") {
		bottom = max(view.Y, bottom-1)
	}
	h = min(h, max(0, bottom-y))
	x := view.X + view.W - w
	switch t.Position {
	case "top-center":
		x = view.X + (view.W-w)/2
	case "bottom-center":
		x = view.X + (view.W-w)/2
		y = max(y, bottom-h)
	case "top-left":
		x = view.X
	case "bottom-left":
		x = view.X
		y = max(y, bottom-h)
	case "bottom-right":
		y = max(y, bottom-h)
	}
	return layout.Rect{X: x, Y: y, W: w, H: h}
}

// --- dialog ---

// DialogRects returns the outer rect and the cancel/confirm button rects.
func DialogRects(d *Dialog, area layout.Rect) (outer, cancel, confirm layout.Rect) {
	cols, rows := area.W, area.H
	if d.InputEdit {
		w, h := min(56, max(0, cols-4)), min(7, max(0, rows-2))
		return layout.Rect{X: area.X + (cols-w)/2, Y: area.Y + (rows-h)/2, W: w, H: h}, layout.Rect{}, layout.Rect{}
	}
	w := len([]rune(d.Title)) + 4
	if l := len([]rune(d.Detail)) + 4; l > w {
		w = l
	}
	for _, ln := range d.Lines {
		if l := len([]rune(ln)) + 4; l > w {
			w = l
		}
	}
	btnRow := ansi.StringWidth("  ↵ "+d.Confirm+"     esc "+d.Cancel+" ") + 4
	if btnRow > w {
		w = btnRow
	}
	if d.Width > w {
		w = d.Width
	}
	// The observed confirmation leaves two columns on each side of the pane area.
	w = min(w, max(cols-4, 0))
	shown := len(d.Lines)
	if shown > 10 {
		shown = 10
	}
	h := 5 + shown
	x := (cols - w) / 2
	y := (rows - h) / 2
	if x < 0 {
		x = 0
	}
	if y < 0 {
		y = 0
	}
	outer = layout.Rect{X: area.X + x, Y: area.Y + y, W: w, H: h}
	x, y = outer.X, outer.Y
	by := y + h - 2
	confirmW := ansi.StringWidth(dialogConfirmLabel(d))
	cancelW := ansi.StringWidth(" esc " + d.Cancel + " ")
	confirm = layout.Rect{X: x + (w-confirmW-cancelW-2)/2, Y: by, W: confirmW, H: 1}
	cancel = layout.Rect{X: confirm.X + confirmW + 2, Y: by, W: cancelW, H: 1}
	if d.ContinueOnly {
		confirm.X = x + 2
		cancel = layout.Rect{}
	}
	return
}

func dialogConfirmLabel(d *Dialog) string {
	if d.DimPanesOnly || d.CompactButtons {
		return " ↵ " + d.Confirm + " "
	}
	return "  ↵ " + d.Confirm + "   "
}

// HelpRect follows the same 76 by 22 cell overlay observed for settings and help.
func HelpRect(cols, rows int) layout.Rect {
	return SettingsRect(cols, rows)
}

// drawHelp renders a title, subtitle, scrollable bindings and footer.
func drawHelp(f *Frame, h *HelpInput, out *Output) {
	r := HelpRect(f.W, f.H)
	x, y, w, hgt := r.X, r.Y, r.W, r.H
	f.Fill(x, y, w, hgt, " ", uv.Style{Bg: f.Palette.PopupBG})
	ix, iy, iw, _ := f.Box(x, y, w, hgt, uv.Style{Fg: f.Palette.Accent, Bg: f.Palette.PopupBG})
	out.HelpRect = r
	if !HelpContentVisible(r) {
		return
	}
	f.Text(ix, iy, "keybinds", uv.Style{Fg: f.Palette.Text, Bg: f.Palette.PopupBG, Attrs: uv.AttrBold}, ix+iw)
	f.Text(x+w-12, iy, " esc close ", uv.Style{Fg: f.Palette.SurfDim, Bg: f.Palette.Accent, Attrs: uv.AttrBold}, ix+iw)
	subtitleStyle := uv.Style{Fg: f.Palette.Overlay1, Bg: f.Palette.PopupBG}
	f.Fill(ix, iy+1, iw, 1, " ", subtitleStyle)
	f.Text(ix+1, iy+1, "available commands and configured shortcuts", subtitleStyle, ix+iw)

	// Distribution observation: title, subtitle, two blank rows, footer and borders.
	body := max(1, hgt-7)
	lines := HelpLines(h.Rows, iw-1, f.Palette)
	scroll := h.Scroll
	if scroll < 0 {
		scroll = 0
	}
	if max := len(lines) - body; scroll > max {
		scroll = max
	}
	if scroll < 0 {
		scroll = 0
	}
	for i := 0; i < body && scroll+i < len(lines); i++ {
		row := lines[scroll+i]
		ry := iy + 3 + i
		for x, cell := range row {
			if cell.Width > 0 {
				f.Set(ix+x, ry, cell.Content, cell.Style)
			}
		}
	}

	if maxScroll := len(lines) - body; maxScroll > 0 {
		thumb, top := HelpThumb(body, len(lines), scroll)
		for i := 0; i < body; i++ {
			glyph, fg := "▕", f.Palette.Dim
			if i >= top && i < top+thumb {
				glyph, fg = "▐", f.Palette.Overlay1
			}
			f.Set(ix+iw-1, iy+3+i, glyph, uv.Style{Fg: fg, Bg: f.Palette.PopupBG})
		}
	}

	// Footer hint on the last inner row.
	footerX := ix
	for _, part := range []struct {
		text string
		fg   color.Color
	}{{" scroll ", f.Palette.Dim}, {"wheel ↑↓", f.Palette.Text},
		{"  ·  jump", f.Palette.Dim}, {" pgup / pgdn ", f.Palette.Text},
		{"  ·  close", f.Palette.Dim}, {" esc / enter ", f.Palette.Text}} {
		footerX = f.Text(footerX, y+hgt-2, part.text, uv.Style{Fg: part.fg, Bg: f.Palette.PopupBG}, ix+iw)
	}
}

// The distribution shows only the frame below 22 columns or 8 rows (help-compact.steps).
func HelpContentVisible(r layout.Rect) bool { return r.W >= 22 && r.H >= 8 }

// HelpThumb follows the observed help pages and narrow wrapped listings.
func HelpThumb(body, total, scroll int) (thumb, top int) {
	thumb = min(body, max(1, int(math.Round(float64(body*body)/float64(max(1, total))))))
	if total > body {
		top = int(math.Round(float64(scroll*(body-thumb)) / float64(total-body)))
	}
	return thumb, top
}

func drawDialog(f *Frame, d *Dialog, out *Output, area layout.Rect) {
	if d.WorktreeCreate {
		drawWorktreeCreate(f, d, out)
		return
	}
	if d.InputEdit {
		drawNameInput(f, d, out)
		return
	}
	outer, cancel, confirm := DialogRects(d, area)
	border := uv.Style{Fg: f.Palette.Red, Bg: f.Palette.PopupBG}
	ix, iy, iw, ih := f.Box(outer.X, outer.Y, outer.W, outer.H, border)
	f.Fill(ix, iy, iw, ih, " ", uv.Style{Bg: f.Palette.PopupBG})
	f.Text(ix, iy, " "+d.Title, uv.Style{Fg: f.Palette.Red, Bg: f.Palette.PopupBG, Attrs: uv.AttrBold}, ix+iw)
	f.Text(ix, iy+1, " "+d.Detail, uv.Style{Fg: f.Palette.Dim, Bg: f.Palette.PopupBG}, ix+iw)
	if d.DimPanesOnly || d.BoldDetailPrefix {
		if at := strings.LastIndex(d.Detail, " — "); at >= 0 {
			f.Text(ix, iy+1, " "+d.Detail[:at], uv.Style{Fg: f.Palette.Text, Bg: f.Palette.PopupBG, Attrs: uv.AttrBold}, ix+iw)
		}
	}
	shown := min(len(d.Lines), 10)
	for i := 0; i < shown; i++ {
		if d.Lines[i] == "" {
			continue
		}
		f.Text(ix, iy+2+i, " "+d.Lines[i], uv.Style{Fg: f.Palette.Dim, Bg: f.Palette.PopupBG}, ix+iw)
	}

	if !d.ContinueOnly {
		f.Text(cancel.X, cancel.Y, " esc "+d.Cancel+" ", uv.Style{Fg: f.Palette.Text, Bg: f.Palette.Surface, Attrs: uv.AttrBold}, cancel.X+cancel.W)
	}
	f.Text(confirm.X, confirm.Y, dialogConfirmLabel(d), uv.Style{Fg: f.Palette.SurfDim, Bg: f.Palette.Red, Attrs: uv.AttrBold}, confirm.X+confirm.W)
	out.DialogRect = outer
	out.DialogCancel = cancel
	out.DialogConfirm = confirm
}

// Button geometry is shared with mouse handling for the recorded name-input box.
var nameInputButtonLabels = [...]string{" ↵ save ", " ^c clear ", " esc cancel "}

func NameInputButtons(r layout.Rect) [3]layout.Rect {
	var buttons [3]layout.Rect
	if r.W < 2 || r.H < 2 {
		return buttons
	}
	width := 2 * (len(buttons) - 1)
	for _, label := range nameInputButtonLabels {
		width += ansi.StringWidth(label)
	}
	x := max(r.X+1, r.X+(r.W-width)/2)
	for i, label := range nameInputButtonLabels {
		buttons[i] = layout.Rect{X: x, Y: min(r.Y+4, r.Y+r.H-2), W: max(0, min(ansi.StringWidth(label), r.X+r.W-1-x)), H: 1}
		x += buttons[i].W + 2
	}
	return buttons
}

func drawNameInput(f *Frame, d *Dialog, out *Output) {
	r, _, _ := DialogRects(d, layout.Rect{W: f.W, H: f.H})
	f.Fill(r.X, r.Y, r.W, r.H, " ", uv.Style{Bg: f.Palette.PopupBG})
	f.Box(r.X, r.Y, r.W, r.H, uv.Style{Fg: f.Palette.Accent, Bg: f.Palette.PopupBG})
	out.DialogRect = r
	if r.H < 7 {
		out.AnchorVisible = false
		return
	}
	title := strings.ToLower(d.Title)
	if d.PreserveTitleCase {
		title = d.Title
	}
	f.Text(r.X+1, r.Y+1, title, uv.Style{Fg: f.Palette.Text, Bg: f.Palette.PopupBG, Attrs: uv.AttrBold}, r.X+r.W-1)
	f.Fill(r.X+1, r.Y+3, r.W-2, 1, " ", uv.Style{Fg: f.Palette.Text, Bg: f.Palette.Surface})
	f.Text(r.X+2, r.Y+3, d.Input, uv.Style{Fg: f.Palette.Text, Bg: f.Palette.Surface}, r.X+r.W-2)
	for i, button := range NameInputButtons(r) {
		style := uv.Style{Fg: f.Palette.Text, Bg: f.Palette.Surface, Attrs: uv.AttrBold}
		if i == 0 {
			style.Fg, style.Bg = f.Palette.SurfDim, f.Palette.Accent
		}
		f.Text(button.X, button.Y, nameInputButtonLabels[i], style, min(button.X+button.W, r.X+r.W-1))
	}
	runes := []rune(d.Input)
	prefix := string(runes[:min(max(0, d.InputCursor), len(runes))])
	out.AnchorX = min(r.X+2+ansi.StringWidth(prefix), r.X+r.W-2)
	out.AnchorY, out.AnchorVisible = r.Y+3, true
	out.AnchorShape = 0
	out.DialogRect = r
}

// --- helpers ---

func label(snap *PaneSnap) string {
	if snap == nil || snap.Label == "" {
		return "—"
	}
	return snap.Label
}

func boldIf(b bool) uint8 {
	if b {
		return uv.AttrBold
	}
	return 0
}
